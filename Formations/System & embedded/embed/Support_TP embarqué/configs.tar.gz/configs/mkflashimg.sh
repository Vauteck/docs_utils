#!/bin/bash
#
# Script to make a flash image made of u-boot, kernel and rootfs
# This flash image is intented to be run with Qemu
#   qemu-system-arm -M versatilepb -m 128M -kernel flash.bin
#
# A. Leclerc - 2010

if [ -z $1 ] || [ ! -d $1 ]; then
	echo "Usage: mkimage.sh <path_to_buildroot_directory>"
	exit 1
fi

#
# Make sure the buildroot directory structure is OK
# and that we have the necessary binaries built
#
MKIMG="$1/output/build/u-boot-*/tools/mkimage"
if [ ! -x $MKIMG ]; then
	echo "Cannot find u-boot mkimage tool"
	exit -1
fi
ODIR="$1/output/images"
if [ ! -d $ODIR ]; then
	echo "Cannot find output directory $ODIR"
	exit 1
fi
ZIMG="$1/output/images/zImage"
RFSZ="$1/output/images/rootfs.cpio.gz"
BOOT="$1/output/images/u-boot.bin"
if [ ! -x $ZIMG ] || [ ! -f $RFSZ ] || [ ! -h $BOOT ]; then
	echo "Cannot find kernel or rootfs or u-boot"
	exit -1
fi

#
# Build the flash image
#
$MKIMG -A arm -C none -O linux -T kernel -d $ZIMG -a 0x00010000 -e 0x00010000 kernel.uimg
if [ 0 -ne $? ]; then
	echo "mkimage kernel failed"
	exit 1;
fi
$MKIMG -A arm -C none -O linux -T ramdisk -d $RFSZ -a 0x00800000 -e 0x00800000 rootfs.uimg
if [ 0 -ne $? ]; then
	echo "mkimage rootfs failed"
	exit 1;
fi
echo "Creating empty flash.bin, this may take some time..."
dd if=/dev/zero of=$ODIR/flash.bin bs=1 count=6M
if [ 0 -ne $? ]; then
	echo "Creation of empty flash.bin failed"
	exit 1;
fi
dd if=$BOOT of=$ODIR/flash.bin conv=notrunc bs=1
if [ 0 -ne $? ]; then
	echo "Adding u-boot.bin to flash.bin failed"
	exit 1;
fi
dd if=kernel.uimg of=$ODIR/flash.bin conv=notrunc bs=1 seek=2M
if [ 0 -ne $? ]; then
	echo "Adding kernel.uimg to flash.bin failed"
	exit 1;
fi
dd if=rootfs.uimg of=$ODIR/flash.bin conv=notrunc bs=1 seek=4M
if [ 0 -ne $? ]; then
	echo "Adding rootfs.uimg to flash.bin failed"
	exit 1;
fi
rm *.uimg

#
# Done
#
echo "$ODIR/flash.bin successfully created"
exit 0
